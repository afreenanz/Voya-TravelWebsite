// plantrip/ItineraryView.jsx
const { useState, useEffect } = React;

const STATUS_CONFIG = {
  upcoming:  { label: 'Upcoming',  bg: 'rgba(47,165,106,0.12)', color: '#1e7a4d' },
  planning:  { label: 'Planning',  bg: 'rgba(55,138,221,0.12)', color: '#144E8E' },
  completed: { label: 'Completed', bg: 'rgba(44,44,42,0.08)',   color: '#4A4842' },
  wishlist:  { label: 'Wishlist',  bg: 'rgba(239,159,39,0.14)', color: '#87520A' },
};

function ActivityRow({ act, isLast }) {
  return (
    <div style={{ display: 'flex', gap: 0, position: 'relative' }}>
      {/* Timeline spine */}
      {!isLast && (
        <div style={{
          position: 'absolute', left: 56, top: 36, bottom: -4,
          width: 1, background: `linear-gradient(to bottom, ${C.borderDefault}, transparent)`,
        }} />
      )}

      {/* Time */}
      <div style={{
        width: 52, flexShrink: 0, paddingTop: 10,
        fontFamily: C.fb, fontSize: 11, fontWeight: 600,
        color: C.fg3, textAlign: 'right', paddingRight: 8,
        letterSpacing: '0.02em',
      }}>{act.time}</div>

      {/* Icon dot */}
      <div style={{
        width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
        background: 'rgba(55,138,221,0.12)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginTop: 4, position: 'relative', zIndex: 1,
      }}>
        <Icon name={act.icon} size={14} color={C.ocean} />
      </div>

      {/* Text */}
      <div style={{ flex: 1, paddingLeft: 12, paddingBottom: isLast ? 0 : 20, paddingTop: 6 }}>
        <div style={{ fontFamily: C.fd, fontWeight: 700, fontSize: 14, color: C.navy, lineHeight: 1.3 }}>
          {act.name}
        </div>
        <div style={{ fontFamily: C.fb, fontSize: 12, color: C.fg3, marginTop: 2, lineHeight: 1.4 }}>
          {act.note}
        </div>
      </div>
    </div>
  );
}

function DayCard({ dayData, index }) {
  const [open, setOpen] = useState(true);
  const dayColors = ['#378ADD', '#EF9F27', '#2FA56A', '#E8859C', '#6FAAEA'];
  const accent = dayColors[index % dayColors.length];

  return (
    <div style={{
      background: '#fff', borderRadius: 20,
      boxShadow: '0 2px 10px rgba(12,68,124,0.07)',
      overflow: 'hidden', marginBottom: 16,
    }}>
      {/* Day header */}
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', padding: '16px 20px', border: 0,
          background: '#fff', cursor: 'pointer', textAlign: 'left',
          display: 'flex', alignItems: 'center', gap: 14,
        }}
      >
        <div style={{
          width: 40, height: 40, borderRadius: 12, flexShrink: 0,
          background: accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span style={{ fontFamily: C.fd, fontWeight: 700, fontSize: 14, color: '#fff' }}>
            D{dayData.day}
          </span>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: C.fd, fontWeight: 700, fontSize: 16, color: C.navy, lineHeight: 1.2 }}>
            {dayData.title}
          </div>
          {dayData.theme && (
            <div style={{ fontFamily: C.fb, fontSize: 12, color: C.fg3, marginTop: 2 }}>{dayData.theme}</div>
          )}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            fontFamily: C.fb, fontSize: 12, color: C.fg3,
          }}>{dayData.activities.length} activities</span>
          <Icon name={open ? 'chevron-up' : 'chevron-down'} size={16} color={C.fg3} />
        </div>
      </button>

      {/* Activities */}
      {open && (
        <div style={{
          padding: '4px 20px 20px',
          borderTop: `1px solid ${C.borderSoft}`,
        }}>
          {dayData.activities.map((act, i) => (
            <ActivityRow key={i} act={act} isLast={i === dayData.activities.length - 1} />
          ))}
        </div>
      )}
    </div>
  );
}

function ItineraryView({ trip, formData, onSave, onBack, isSaved }) {
  const [saved, setSaved] = useState(isSaved || false);

  const displayTrip = trip || (formData && window.TRIPS_DATA.find(t =>
    t.destination.toLowerCase() === (formData.dest || '').toLowerCase()
  )) || window.TRIPS_DATA[0];

  const st = STATUS_CONFIG[displayTrip.status] || STATUS_CONFIG.planning;

  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  const handleSave = () => { setSaved(true); if (onSave) onSave(displayTrip); };

  return (
    <div style={{ flex: 1, overflowY: 'auto', background: C.cream }}>

      {/* Hero banner */}
      <div style={{
        background: displayTrip.gradient,
        padding: '36px 52px 32px', position: 'relative', overflow: 'hidden',
      }}>
        {/* Deco route */}
        <svg viewBox="0 0 600 120" width="600" height="120" style={{
          position: 'absolute', right: 0, top: 0, opacity: 0.18, pointerEvents: 'none',
        }}>
          <path d="M 30 90 C 120 20, 320 10, 480 60 S 560 100, 620 50"
            fill="none" stroke="#fff" strokeWidth="2"
            strokeDasharray="4 10" strokeLinecap="round" />
        </svg>

        {onBack && (
          <button onClick={onBack} style={{
            background: 'rgba(255,255,255,0.18)', border: 0, borderRadius: 10,
            padding: '6px 14px', cursor: 'pointer', marginBottom: 20,
            display: 'flex', alignItems: 'center', gap: 6,
            fontFamily: C.fb, fontWeight: 600, fontSize: 13, color: '#fff',
          }}>
            <Icon name="arrow-left" size={14} color="#fff" />
            Back
          </button>
        )}

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 36, marginBottom: 6 }}>{displayTrip.flag}</div>
            <h1 style={{
              fontFamily: C.fd, fontWeight: 700, fontSize: 40,
              color: '#fff', margin: '0 0 4px', letterSpacing: '-0.025em',
            }}>{displayTrip.destination} Trip</h1>
            <p style={{ fontFamily: C.fb, fontSize: 15, color: 'rgba(255,255,255,0.72)', margin: 0 }}>
              {displayTrip.cities}
            </p>
          </div>
          <span style={{
            background: st.bg, color: st.color,
            fontFamily: C.fd, fontWeight: 700, fontSize: 12,
            padding: '6px 14px', borderRadius: 99, letterSpacing: '0.06em',
            textTransform: 'uppercase', backdropFilter: 'blur(8px)',
            border: '1px solid rgba(255,255,255,0.2)',
          }}>{st.label}</span>
        </div>

        {/* Stats strip */}
        <div style={{
          display: 'flex', gap: 0, marginTop: 28,
          background: 'rgba(255,255,255,0.15)', borderRadius: 16,
          backdropFilter: 'blur(10px)', overflow: 'hidden',
        }}>
          {[
            { icon: 'moon',      label: 'Duration',  val: `${displayTrip.days} days` },
            { icon: 'banknote',  label: 'Budget',    val: displayTrip.budget },
            { icon: 'calendar',  label: 'Dates',     val: `${displayTrip.startDate} – ${displayTrip.endDate}` },
            { icon: 'users',     label: 'Travelers', val: `${displayTrip.travelers} people` },
            { icon: 'compass',   label: 'Style',     val: displayTrip.travelStyle },
          ].map((s, i, arr) => (
            <div key={s.label} style={{
              flex: 1, padding: '14px 18px',
              borderRight: i < arr.length - 1 ? '1px solid rgba(255,255,255,0.20)' : 'none',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                <Icon name={s.icon} size={13} color="rgba(255,255,255,0.70)" />
                <span style={{ fontFamily: C.fb, fontSize: 11, color: 'rgba(255,255,255,0.60)' }}>{s.label}</span>
              </div>
              <div style={{ fontFamily: C.fd, fontWeight: 700, fontSize: 14, color: '#fff' }}>{s.val}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Itinerary body */}
      <div style={{ padding: '32px 52px 60px' }}>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 28 }}>
          <button
            onClick={handleSave}
            style={{
              padding: '10px 22px', borderRadius: 99, border: 0, cursor: 'pointer',
              background: saved ? 'rgba(47,165,106,0.12)' : C.amber,
              color: saved ? '#1e7a4d' : '#fff',
              fontFamily: C.fd, fontWeight: 700, fontSize: 14,
              boxShadow: saved ? 'none' : '0 6px 20px rgba(239,159,39,0.30)',
              display: 'flex', alignItems: 'center', gap: 7,
              transition: 'all 220ms',
            }}
          >
            <Icon name={saved ? 'check' : 'bookmark-plus'} size={15} color={saved ? '#1e7a4d' : '#fff'} />
            {saved ? 'Saved to My Trips' : 'Save to My Trips'}
          </button>
          <button style={{
            padding: '10px 20px', borderRadius: 99,
            border: `1.5px solid ${C.navy}`, background: 'transparent',
            color: C.navy, fontFamily: C.fd, fontWeight: 700, fontSize: 14,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7,
          }}>
            <Icon name="sparkles" size={15} color={C.navy} />
            Modify with AI
          </button>
          <button style={{
            padding: '10px 20px', borderRadius: 99, border: 0,
            background: C.sky, color: C.navy,
            fontFamily: C.fd, fontWeight: 700, fontSize: 14,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7,
          }}>
            <Icon name="share-2" size={15} color={C.navy} />
            Share
          </button>
        </div>

        {/* Section label */}
        <div style={{
          fontFamily: C.fd, fontWeight: 700, fontSize: 11,
          letterSpacing: '0.16em', textTransform: 'uppercase',
          color: C.ocean, marginBottom: 16,
        }}>DAY-BY-DAY ITINERARY</div>

        {/* Day cards */}
        {displayTrip.itinerary.map((day, i) => (
          <DayCard key={day.day} dayData={day} index={i} />
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ItineraryView, STATUS_CONFIG });
