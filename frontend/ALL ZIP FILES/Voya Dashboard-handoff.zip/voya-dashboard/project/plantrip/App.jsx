// plantrip/App.jsx — Voya Plan Trip root
const { useState, useEffect, useRef } = React;

// ─── Loading screen ───────────────────────────────────────────
function LoadingView({ dest, onDone }) {
  const steps = [
    'Scanning 2,400 flights…',
    'Checking hotel availability…',
    'Building your day-by-day plan…',
    'Adding local tips & hidden gems…',
    'Finalising your itinerary ✈️',
  ];
  const [step, setStep] = useState(0);
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const total = 2200;
    const start = Date.now();
    const pctTimer = setInterval(() => {
      const elapsed = Date.now() - start;
      const p = Math.min(100, Math.round((elapsed / total) * 100));
      setPct(p);
      if (p >= 100) clearInterval(pctTimer);
    }, 40);
    const stepTimer = setInterval(() => {
      setStep(s => (s < steps.length - 1 ? s + 1 : s));
    }, 420);
    const doneTimer = setTimeout(onDone, total);
    return () => { clearInterval(pctTimer); clearInterval(stepTimer); clearTimeout(doneTimer); };
  }, []);

  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: C.cream, padding: 40,
    }}>
      {/* Animated route SVG */}
      <div style={{ marginBottom: 36, position: 'relative', width: 260, height: 120 }}>
        <svg viewBox="0 0 260 120" width="260" height="120">
          <path
            d="M 20 95 C 80 20, 170 10, 240 65"
            fill="none" stroke={C.borderDefault} strokeWidth="2"
            strokeDasharray="4 9" strokeLinecap="round"
          />
          <path
            d="M 20 95 C 80 20, 170 10, 240 65"
            fill="none" stroke={C.ocean} strokeWidth="2.5"
            strokeDasharray="4 9" strokeLinecap="round"
            style={{
              strokeDashoffset: 0,
              animation: 'dashFlow 1.2s linear infinite',
            }}
          />
          {/* Plane */}
          <g transform="translate(8,83) rotate(-36)">
            <path d="M0 6L12 0v3.5l-6 1.5v7l2 2-4-1-2 1 2-2V7.5z"
              fill={C.ocean} />
          </g>
          {/* Pin */}
          <g transform="translate(228,52)">
            <path d="M9 0C4.1 0 0 4 0 9c0 6.6 9 16 9 16s9-9.4 9-16C18 4 14 0 9 0Z"
              fill={C.amber} />
            <circle cx="9" cy="9" r="3" fill="rgba(255,255,255,0.9)" />
          </g>
        </svg>
      </div>

      <div style={{
        fontFamily: C.fd, fontWeight: 700, fontSize: 28,
        color: C.navy, letterSpacing: '-0.02em', marginBottom: 8, textAlign: 'center',
      }}>
        Crafting your {dest} itinerary…
      </div>

      <div style={{
        fontFamily: C.fb, fontSize: 15, color: C.fg3,
        marginBottom: 36, textAlign: 'center', height: 22,
        transition: 'opacity 300ms',
      }}>
        {steps[step]}
      </div>

      {/* Progress bar */}
      <div style={{ width: 320, maxWidth: '100%' }}>
        <div style={{ height: 6, background: C.sky, borderRadius: 99, overflow: 'hidden' }}>
          <div style={{
            height: '100%', borderRadius: 99,
            background: `linear-gradient(90deg, ${C.ocean}, ${C.amber})`,
            width: `${pct}%`, transition: 'width 80ms linear',
          }} />
        </div>
        <div style={{
          display: 'flex', justifyContent: 'space-between', marginTop: 8,
          fontFamily: C.fb, fontSize: 12, color: C.fg3,
        }}>
          <span>Voya AI</span>
          <span>{pct}%</span>
        </div>
      </div>
    </div>
  );
}

// ─── App root ─────────────────────────────────────────────────
function PlanTripApp() {
  const [view, setView] = useState(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash === 'trips') return 'trips';
    return 'form';
  });
  const [formData, setFormData]         = useState(null);
  const [selectedTrip, setSelectedTrip] = useState(null);

  const handleGenerate = (data) => {
    setFormData(data);
    setView('loading');
  };

  const handleLoadingDone = () => setView('itinerary');

  const handleSelectTrip = (trip) => {
    setSelectedTrip(trip);
    setView('tripDetail');
  };

  const handleSetView = (v) => {
    setView(v);
    if (v !== 'tripDetail') setSelectedTrip(null);
  };

  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <PTSidebar activeView={view} onSetView={handleSetView} />

      {view === 'form' && (
        <PlanForm onGenerate={handleGenerate} />
      )}
      {view === 'loading' && (
        <LoadingView dest={formData?.dest || 'your'} onDone={handleLoadingDone} />
      )}
      {view === 'itinerary' && (
        <ItineraryView
          formData={formData}
          onSave={() => {}}
          onBack={() => setView('form')}
        />
      )}
      {view === 'trips' && (
        <MyTripsView onSelectTrip={handleSelectTrip} />
      )}
      {view === 'tripDetail' && selectedTrip && (
        <ItineraryView
          trip={selectedTrip}
          isSaved={true}
          onBack={() => setView('trips')}
        />
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<PlanTripApp />);
