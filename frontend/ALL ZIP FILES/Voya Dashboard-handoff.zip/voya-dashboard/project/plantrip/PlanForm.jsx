// plantrip/PlanForm.jsx
const { useState, useEffect } = React;

const DESTINATIONS_LIST = [
  { name: 'Thailand',    flag: '🇹🇭', hint: 'Bangkok · Beaches · Temples' },
  { name: 'Bali',        flag: '🇮🇩', hint: 'Temples · Rice Fields · Surf' },
  { name: 'Japan',       flag: '🇯🇵', hint: 'Tokyo · Kyoto · Cherry Blossoms' },
  { name: 'Dubai',       flag: '🇦🇪', hint: 'Skyline · Desert · Luxury' },
  { name: 'Goa',         flag: '🇮🇳', hint: 'Beaches · Nightlife · Portuguese' },
  { name: 'Maldives',    flag: '🇲🇻', hint: 'Overwater Villas · Coral Reefs' },
  { name: 'Vietnam',     flag: '🇻🇳', hint: 'Hoi An · Ha Long Bay · Pho' },
  { name: 'Switzerland', flag: '🇨🇭', hint: 'Alps · Lakes · Trains · Chocolate' },
  { name: 'Paris',       flag: '🇫🇷', hint: 'Eiffel Tower · Art · Cuisine' },
  { name: 'New York',    flag: '🇺🇸', hint: 'Manhattan · Central Park · Jazz' },
];

const TRAVEL_STYLES = [
  { id: 'adventure',   label: 'Adventure',    icon: 'mountain' },
  { id: 'cultural',    label: 'Cultural',     icon: 'landmark' },
  { id: 'relaxation',  label: 'Relaxation',   icon: 'sun' },
  { id: 'food',        label: 'Food & Dining',icon: 'utensils' },
  { id: 'romantic',    label: 'Romantic',     icon: 'heart' },
  { id: 'family',      label: 'Family',       icon: 'users' },
];

const BUDGET_OPTIONS = ['₹30,000', '₹50,000', '₹75,000', '₹1,00,000', '₹1,50,000+'];

function PlanForm({ onGenerate }) {
  const [dest, setDest]           = useState('');
  const [showSugg, setShowSugg]   = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate]     = useState('');
  const [budget, setBudget]       = useState('₹60,000');
  const [travelers, setTravelers] = useState(2);
  const [styles, setStyles]       = useState(['cultural', 'food']);

  const filtered = DESTINATIONS_LIST.filter(d =>
    dest.length === 0 || d.name.toLowerCase().includes(dest.toLowerCase())
  );

  const toggleStyle = (id) => setStyles(prev =>
    prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
  );

  const canGenerate = dest.trim().length > 0;

  useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  const inputStyle = {
    width: '100%', border: `1.5px solid ${C.borderDefault}`,
    borderRadius: 14, outline: 'none', fontFamily: C.fb,
    fontSize: 14, color: C.ink, background: C.sky,
    transition: 'border-color 150ms',
  };

  const labelStyle = {
    display: 'block', fontFamily: C.fd, fontWeight: 700, fontSize: 13,
    color: C.navy, marginBottom: 8, letterSpacing: '-0.01em',
  };

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '40px 52px 60px', background: C.cream }}>
      {/* Page header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{
          fontFamily: C.fd, fontWeight: 700, fontSize: 11,
          letterSpacing: '0.16em', textTransform: 'uppercase',
          color: C.ocean, marginBottom: 8,
        }}>AI TRIP PLANNER</div>
        <h1 style={{
          fontFamily: C.fd, fontWeight: 700, fontSize: 34,
          color: C.navy, margin: 0, letterSpacing: '-0.02em', lineHeight: 1.1,
        }}>Plan your perfect trip</h1>
        <p style={{ fontFamily: C.fb, fontSize: 15, color: C.fg3, marginTop: 8, lineHeight: 1.5 }}>
          Tell Voya where you want to go and we'll handle everything else.
        </p>
      </div>

      {/* Form card */}
      <div style={{
        background: '#fff', borderRadius: 24, padding: '32px 36px',
        boxShadow: '0 4px 20px rgba(12,68,124,0.07)',
        display: 'flex', flexDirection: 'column', gap: 28, maxWidth: 680,
      }}>

        {/* Destination */}
        <div>
          <label style={labelStyle}>Destination</label>
          <div style={{ position: 'relative' }}>
            <div style={{ position: 'relative' }}>
              <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', display: 'flex' }}>
                <Icon name="map-pin" size={17} color={C.ocean} />
              </span>
              <input
                value={dest}
                onChange={e => { setDest(e.target.value); setShowSugg(true); }}
                onFocus={() => setShowSugg(true)}
                onBlur={() => setTimeout(() => setShowSugg(false), 150)}
                placeholder="Where do you want to go?"
                style={{ ...inputStyle, padding: '13px 16px 13px 42px', fontSize: 16, fontFamily: C.fd, fontWeight: 600 }}
              />
            </div>
            {showSugg && filtered.length > 0 && (
              <div style={{
                position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, zIndex: 100,
                background: '#fff', borderRadius: 16, overflow: 'hidden',
                boxShadow: '0 8px 28px rgba(12,68,124,0.14)',
                border: `1px solid ${C.borderSoft}`,
              }}>
                {filtered.slice(0, 6).map(d => (
                  <div
                    key={d.name}
                    onMouseDown={() => { setDest(d.name); setShowSugg(false); }}
                    style={{ padding: '11px 16px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}
                    onMouseEnter={e => e.currentTarget.style.background = C.sky}
                    onMouseLeave={e => e.currentTarget.style.background = '#fff'}
                  >
                    <span style={{ fontSize: 22 }}>{d.flag}</span>
                    <div>
                      <div style={{ fontFamily: C.fd, fontWeight: 700, fontSize: 14, color: C.navy }}>{d.name}</div>
                      <div style={{ fontFamily: C.fb, fontSize: 12, color: C.fg3 }}>{d.hint}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Dates */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {[
            { label: 'Start date', val: startDate, set: setStartDate },
            { label: 'End date',   val: endDate,   set: setEndDate },
          ].map(({ label, val, set }) => (
            <div key={label}>
              <label style={labelStyle}>{label}</label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', display: 'flex' }}>
                  <Icon name="calendar" size={16} color={C.ocean} />
                </span>
                <input
                  type="date"
                  value={val}
                  onChange={e => set(e.target.value)}
                  style={{ ...inputStyle, padding: '12px 14px 12px 38px', cursor: 'pointer' }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Budget */}
        <div>
          <label style={labelStyle}>Budget</label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {BUDGET_OPTIONS.map(b => {
              const on = budget === b;
              return (
                <button key={b} onClick={() => setBudget(b)} style={{
                  padding: '8px 18px', borderRadius: 99,
                  border: `1.5px solid ${on ? C.ocean : C.borderDefault}`,
                  background: on ? 'rgba(55,138,221,0.10)' : '#fff',
                  color: on ? C.ocean : C.fg2,
                  fontFamily: C.fd, fontWeight: 600, fontSize: 13,
                  cursor: 'pointer', transition: 'all 140ms',
                }}>{b}</button>
              );
            })}
          </div>
        </div>

        {/* Travelers */}
        <div>
          <label style={labelStyle}>Number of travelers</label>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{
              display: 'flex', alignItems: 'center',
              border: `1.5px solid ${C.borderDefault}`, borderRadius: 14,
              overflow: 'hidden', background: C.sky,
            }}>
              <button onClick={() => setTravelers(t => Math.max(1, t - 1))} style={{
                width: 44, height: 44, border: 0, background: 'transparent', cursor: 'pointer',
                fontFamily: C.fd, fontWeight: 700, fontSize: 20, color: C.navy,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>−</button>
              <div style={{ width: 44, textAlign: 'center', fontFamily: C.fd, fontWeight: 700, fontSize: 18, color: C.navy }}>{travelers}</div>
              <button onClick={() => setTravelers(t => Math.min(20, t + 1))} style={{
                width: 44, height: 44, border: 0, background: 'transparent', cursor: 'pointer',
                fontFamily: C.fd, fontWeight: 700, fontSize: 20, color: C.navy,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>+</button>
            </div>
            <span style={{ fontFamily: C.fb, fontSize: 14, color: C.fg3 }}>
              {travelers === 1 ? '1 traveler' : `${travelers} travelers`}
            </span>
          </div>
        </div>

        {/* Travel Style */}
        <div>
          <label style={labelStyle}>Travel style <span style={{ fontWeight: 400, color: C.fg3, fontSize: 12 }}>(pick all that apply)</span></label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {TRAVEL_STYLES.map(s => {
              const on = styles.includes(s.id);
              return (
                <button key={s.id} onClick={() => toggleStyle(s.id)} style={{
                  padding: '8px 16px', borderRadius: 99,
                  border: `1.5px solid ${on ? C.ocean : C.borderDefault}`,
                  background: on ? 'rgba(55,138,221,0.10)' : '#fff',
                  color: on ? C.ocean : C.fg2,
                  fontFamily: C.fd, fontWeight: 600, fontSize: 13,
                  cursor: 'pointer', transition: 'all 140ms',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <Icon name={s.icon} size={13} color={on ? C.ocean : C.fg3} />
                  {s.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={() => canGenerate && onGenerate({ dest, startDate, endDate, budget, travelers, styles })}
          style={{
            width: '100%', padding: '17px', borderRadius: 99, border: 0,
            cursor: canGenerate ? 'pointer' : 'not-allowed',
            background: canGenerate ? C.amber : C.borderDefault,
            color: '#fff', fontFamily: C.fd, fontWeight: 700, fontSize: 17,
            letterSpacing: '-0.01em',
            boxShadow: canGenerate ? '0 8px 28px rgba(239,159,39,0.34)' : 'none',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            transition: 'all 200ms',
            opacity: canGenerate ? 1 : 0.45,
          }}
        >
          <Icon name="sparkles" size={18} color="#fff" />
          Generate itinerary
          <Icon name="arrow-right" size={18} color="#fff" />
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { PlanForm });
